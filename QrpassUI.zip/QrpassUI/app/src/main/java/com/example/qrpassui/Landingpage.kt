package com.example.qrpassui

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_landingpagee.*

class Landingpage : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_landingpagee)

        btnStart.setOnClickListener{
            val intent = Intent(this, Homeportal::class.java);
            startActivity(intent);
        }
    }

}