package com.example.qrpassui

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class InUserEstab : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_in_user_estab)
    }
}