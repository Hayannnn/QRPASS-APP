package com.example.qrpassui

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_homeportal.*

class Homeportal : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_homeportal)

        btnUser.setOnClickListener{
            val intent = Intent(this, MainActivity::class.java);
            startActivity(intent);
        }
        btnEstablishment.setOnClickListener{
            val intent = Intent(this, LoginEstablishment::class.java);
            startActivity(intent);
        }
    }
}